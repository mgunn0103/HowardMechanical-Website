<?php

class ITSEC_Salts_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'salts';
	protected $_name = 'Salts';
	protected $_desc = 'Change your salts.';
}
new ITSEC_Salts_Module_Init();
