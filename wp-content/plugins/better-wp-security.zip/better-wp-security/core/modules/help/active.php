<?php
// Set up Help Admin
require_once( 'class-itsec-help-admin.php' );
$itsec_help_admin = new ITSEC_Help_Admin();
$itsec_help_admin->run();
