<?php

class ITSEC_Help_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'help';
	protected $_name = 'Help';
	protected $_desc = 'Help.';
}
new ITSEC_Help_Module_Init();
